"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/about.ts
var about_exports = {};
__export(about_exports, {
  default: () => about_default
});
module.exports = __toCommonJS(about_exports);

// netlify/functions/common.ts
var import_blobs = require("@netlify/blobs");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Admin-Key",
  "Content-Type": "application/json; charset=UTF-8"
};
function sendJson(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: corsHeaders
  });
}
function sendError(message, status = 400) {
  return sendJson({ error: message }, status);
}
function getAdminKey() {
  return process.env.ADMIN_KEY || "changeme-admin-key";
}
function isAdminRequest(request) {
  const provided = request.headers.get("X-Admin-Key") || "";
  return provided === getAdminKey();
}
function requireAdmin(request) {
  if (!isAdminRequest(request)) {
    throw new Error("Admin authentication required");
  }
}
async function readData(context, key) {
  try {
    const store = (0, import_blobs.getStore)("silans-data");
    const data = await store.get(key, { type: "json" });
    return data || [];
  } catch (err) {
    console.error(`Error reading ${key}:`, err);
    return [];
  }
}
async function writeData(context, key, data) {
  try {
    const store = (0, import_blobs.getStore)("silans-data");
    await store.setJSON(key, data);
  } catch (err) {
    console.error(`Error writing ${key}:`, err);
    throw err;
  }
}
async function logAction(context, type, details = {}) {
  try {
    const store = (0, import_blobs.getStore)("silans-data");
    const logs = await store.get("audit.log", { type: "text" }) || "";
    const entry = JSON.stringify({
      ts: Date.now(),
      type,
      details,
      ip: context.ip
    });
    await store.set("audit.log", logs + entry + "\\n", { metadata: { type: "text/plain" } });
  } catch (err) {
    console.error("Error logging action:", err);
  }
}

// netlify/functions/about.ts
var about_default = async (request, context) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  try {
    switch (request.method) {
      case "GET": {
        const aboutData = await readData(context, "about.json");
        const about = aboutData[0] || {
          title: "About Me",
          content: "Professional auto detailing service",
          image: ""
        };
        return sendJson(about);
      }
      case "POST": {
        requireAdmin(request);
        const input = await request.json();
        if (!input.title || !input.content) {
          return sendError("Title and content are required", 400);
        }
        const about = {
          title: input.title.trim(),
          content: input.content.trim(),
          image: input.image || "",
          updatedAt: Date.now()
        };
        await writeData(context, "about.json", [about]);
        await logAction(context, "about.update", { title: about.title });
        return sendJson({ success: true, about });
      }
      default:
        return sendError("Method not allowed", 405);
    }
  } catch (err) {
    console.error("About error:", err);
    return sendError(err.message || "Internal server error", 500);
  }
};
