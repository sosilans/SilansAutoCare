"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/audit.ts
var audit_exports = {};
__export(audit_exports, {
  default: () => audit_default
});
module.exports = __toCommonJS(audit_exports);

// netlify/functions/common.ts
var import_blobs = require("@netlify/blobs");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Admin-Key",
  "Content-Type": "application/json; charset=UTF-8"
};
function sendJson(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: corsHeaders
  });
}
function sendError(message, status = 400) {
  return sendJson({ error: message }, status);
}
function getAdminKey() {
  return process.env.ADMIN_KEY || "changeme-admin-key";
}
function isAdminRequest(request) {
  const provided = request.headers.get("X-Admin-Key") || "";
  return provided === getAdminKey();
}
function requireAdmin(request) {
  if (!isAdminRequest(request)) {
    throw new Error("Admin authentication required");
  }
}

// netlify/functions/audit.ts
var audit_default = async (request, context) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  if (request.method !== "GET") {
    return sendError("Method not allowed", 405);
  }
  try {
    requireAdmin(request);
    const { getStore: getStore2 } = await import("@netlify/blobs");
    const store = getStore2("silans-data");
    const logs = await store.get("audit.log", { type: "text" }) || "";
    const entries = logs.trim().split("\n").filter(Boolean).map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    }).filter(Boolean);
    return sendJson({ logs: entries });
  } catch (err) {
    console.error("Audit error:", err);
    return sendError(err.message || "Internal server error", 500);
  }
};
