"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/bootstrap.ts
var bootstrap_exports = {};
__export(bootstrap_exports, {
  default: () => bootstrap_default
});
module.exports = __toCommonJS(bootstrap_exports);

// netlify/functions/common.ts
var import_blobs = require("@netlify/blobs");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Admin-Key",
  "Content-Type": "application/json; charset=UTF-8"
};
function sendJson(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: corsHeaders
  });
}
function sendError(message, status = 400) {
  return sendJson({ error: message }, status);
}
async function readData(context, key) {
  try {
    const store = (0, import_blobs.getStore)("silans-data");
    const data = await store.get(key, { type: "json" });
    return data || [];
  } catch (err) {
    console.error(`Error reading ${key}:`, err);
    return [];
  }
}

// netlify/functions/bootstrap.ts
var bootstrap_default = async (request, context) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  if (request.method !== "GET") {
    return sendError("Method not allowed", 405);
  }
  try {
    const [reviews, faqs, users] = await Promise.all([
      readData(context, "reviews.json"),
      readData(context, "faqs.json"),
      readData(context, "users.json")
    ]);
    const statusRaw = await readData(context, "status.json");
    const status = { available: statusRaw[0]?.available ?? true };
    const approvedReviews = reviews.filter((r) => r.approved);
    const pendingReviews = reviews.filter((r) => !r.approved);
    let sumRating = 0, countRating = 0;
    approvedReviews.forEach((r) => {
      if (r.rating) {
        sumRating += r.rating;
        countRating++;
      }
    });
    const stats = {
      totalReviews: reviews.length,
      approvedReviews: approvedReviews.length,
      pendingReviews: pendingReviews.length,
      totalUsers: users.length,
      totalFaqs: faqs.length,
      averageRating: countRating ? Math.round(sumRating / countRating * 100) / 100 : 0,
      lastUpdated: Date.now()
    };
    const about = await readData(context, "about.json");
    return sendJson({
      reviews,
      faqs,
      stats,
      status,
      about: about[0] || {}
    });
  } catch (err) {
    console.error("Bootstrap error:", err);
    return sendError(err.message || "Internal server error", 500);
  }
};
