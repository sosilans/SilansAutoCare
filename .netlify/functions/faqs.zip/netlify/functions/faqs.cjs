"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/faqs.ts
var faqs_exports = {};
__export(faqs_exports, {
  default: () => faqs_default
});
module.exports = __toCommonJS(faqs_exports);

// netlify/functions/common.ts
var import_blobs = require("@netlify/blobs");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Admin-Key",
  "Content-Type": "application/json; charset=UTF-8"
};
function sendJson(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: corsHeaders
  });
}
function sendError(message, status = 400) {
  return sendJson({ error: message }, status);
}
function getAdminKey() {
  return process.env.ADMIN_KEY || "changeme-admin-key";
}
function isAdminRequest(request) {
  const provided = request.headers.get("X-Admin-Key") || "";
  return provided === getAdminKey();
}
function requireAdmin(request) {
  if (!isAdminRequest(request)) {
    throw new Error("Admin authentication required");
  }
}
function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
async function readData(context, key) {
  try {
    const store = (0, import_blobs.getStore)("silans-data");
    const data = await store.get(key, { type: "json" });
    return data || [];
  } catch (err) {
    console.error(`Error reading ${key}:`, err);
    return [];
  }
}
async function writeData(context, key, data) {
  try {
    const store = (0, import_blobs.getStore)("silans-data");
    await store.setJSON(key, data);
  } catch (err) {
    console.error(`Error writing ${key}:`, err);
    throw err;
  }
}
async function logAction(context, type, details = {}) {
  try {
    const store = (0, import_blobs.getStore)("silans-data");
    const logs = await store.get("audit.log", { type: "text" }) || "";
    const entry = JSON.stringify({
      ts: Date.now(),
      type,
      details,
      ip: context.ip
    });
    await store.set("audit.log", logs + entry + "\\n", { metadata: { type: "text/plain" } });
  } catch (err) {
    console.error("Error logging action:", err);
  }
}

// netlify/functions/faqs.ts
var faqs_default = async (request, context) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  try {
    const faqs = await readData(context, "faqs.json");
    switch (request.method) {
      case "GET":
        return sendJson({ faqs });
      case "POST": {
        requireAdmin(request);
        const input = await request.json();
        if (!input.question || !input.answer) {
          return sendError("Question and answer are required", 400);
        }
        const faq = {
          id: generateId(),
          question: input.question.trim(),
          answer: input.answer.trim(),
          createdAt: Date.now()
        };
        faqs.push(faq);
        await writeData(context, "faqs.json", faqs);
        await logAction(context, "faq.create", { id: faq.id });
        return sendJson({ success: true, faq }, 201);
      }
      case "PUT": {
        requireAdmin(request);
        const input = await request.json();
        if (!input.id) {
          return sendError("FAQ ID is required", 400);
        }
        const faq = faqs.find((f) => f.id === input.id);
        if (!faq) {
          return sendError("FAQ not found", 404);
        }
        if (input.question) faq.question = input.question.trim();
        if (input.answer) faq.answer = input.answer.trim();
        await writeData(context, "faqs.json", faqs);
        await logAction(context, "faq.update", { id: input.id });
        return sendJson({ success: true });
      }
      case "DELETE": {
        requireAdmin(request);
        const url = new URL(request.url);
        const id = url.searchParams.get("id");
        if (!id) {
          return sendError("FAQ ID is required", 400);
        }
        const filtered = faqs.filter((f) => f.id !== id);
        if (filtered.length === faqs.length) {
          return sendError("FAQ not found", 404);
        }
        await writeData(context, "faqs.json", filtered);
        await logAction(context, "faq.delete", { id });
        return sendJson({ success: true });
      }
      default:
        return sendError("Method not allowed", 405);
    }
  } catch (err) {
    console.error("FAQs error:", err);
    return sendError(err.message || "Internal server error", 500);
  }
};
