"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/send-telegram.ts
var send_telegram_exports = {};
__export(send_telegram_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(send_telegram_exports);
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const data = JSON.parse(event.body || "{}");
    if (!data.name || !data.email || !data.message) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing required fields" })
      };
    }
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    if (!botToken || !chatId) {
      console.error("Telegram credentials not configured");
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Telegram not configured" })
      };
    }
    const telegramMessage = `
\u{1F514} *New Contact Form Submission*

\u{1F464} *Name:* ${data.name}
\u{1F4E7} *Email:* ${data.email}
${data.phone ? `\u{1F4F1} *Phone:* ${data.phone}
` : ""}
\u{1F4AC} *Message:*
${data.message}

\u23F0 *Time:* ${(/* @__PURE__ */ new Date()).toLocaleString("en-US", { timeZone: "Europe/Moscow" })}
    `.trim();
    const telegramResponse = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: telegramMessage,
          parse_mode: "Markdown"
        })
      }
    );
    const result = await telegramResponse.json();
    if (!telegramResponse.ok) {
      console.error("Telegram API error:", result);
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "Failed to send Telegram message",
          details: result
        })
      };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        message: "Message sent to Telegram successfully"
      })
    };
  } catch (error) {
    console.error("Error in send-telegram function:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
